<?php
$con=mysqli_connect("sql302.infinityfree.com","if0_35948912","VVmqb0u0NCp8","if0_35948912_sweet_delights");
?>